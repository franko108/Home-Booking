<?php
$welcome = '<p>Setup proces za program u kojem treba biti postavljena baza podataka i konfiguracija za rad
na programu <b>Home-booking</b> </p>
<p>Welcome to setup process for program <b>Home-booking</b></p>';

$language = 'Odaberite jezik instalacije / Please, select the language for installation process';

$failure_table = 'Failure on creating table';
?>