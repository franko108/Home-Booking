<?php

$lang['currency_entry'] = "Currency Entry ";
$lang['currency_name'] = 'Name ';
$lang['header_name'] = 'NAME' ;

$lang['curreny_edit'] = 'Edit currency data';

$lang['currency_notdeleted'] = 'Currency can not be deleted because it exists in income or outcome values!';
