<?php
$language = $this->lang->lang();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="<?php echo base_url(); ?>css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>css/help.css" rel="stylesheet" type="text/css"  />
<title>Vrste uplata/isplata</title>
</head>
<body>
<p>&nbsp;</p>
<div class="col1">
	&nbsp;
</div>
<?php include('menu_help.php'); ?>

<p>&nbsp;</p><br /><br />
<hr class="hr" />
<div class="main">

<h1 align="center">Pregled unosa po kategorijama uplata/isplata</h1>
<p>
Ovaj izvještaj nalazi se na meniju: <i>Izvještaji->Izv. po vrstama</i> i prikazuje zbroj prihoda ili rashoda po definiranim kategorijama.
<br><br>
Kao i kod pregleda svih unosa, nalazi se mogućnost izmjene datauma unutar kojeg su prikazani izvještaji. Početno su postavljene sume po kategorijama 
unutar cijelog dostupnog razdoblja.
<br>Ispod toga nalazi se ispis ukupnog zbroja prihoda i rashoda po valutama.
<br><br>Tabela sa slike 1 prikazuje sumarni pregled uplata ili isplata po kategorijama. Kao i kod pregleda svih unosa, klikom na naslov kolone, zapisi su poredani po redu
s obzirom na zapise u koloni.
<br>
<br>
<br>
<br>
Slika 1.
<br>
<img src="<?php echo base_url(); ?>/help-pictures/hr/kategorijeIzvj.png" border="1">
</p>
</div>
</body>
</html>