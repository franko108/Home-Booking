<div class="col2">
	<?php echo anchor('help/index','About program');  ?>
	<br />
	<?php echo anchor('help/index#license','License');  ?>
	<br />
	<?php echo anchor('help/index#inst','Installation');  ?>

</div>

<div class="col3">
	<?php echo anchor('help/guide','Settings');  ?>
	<br />
	<?php echo anchor('help/recording','Booking');  ?>
	<br />
	<?php echo anchor('help/transaction','Transaction');  ?>
</div>

<div class="col4">
	<?php echo anchor('help/allRecords','All records');  ?>
	<br />
	<?php echo anchor('help/categories','Category reports');  ?>
	<br />
	<?php echo anchor('help/search','Search');  ?>
	<br />
	<?php echo anchor('help/backup','Backup');  ?>
	

</div> 