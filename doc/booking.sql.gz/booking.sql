#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS accounts;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `deff` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO accounts (`id`, `name`, `deff`) VALUES (9, 'OTP', 0);
INSERT INTO accounts (`id`, `name`, `deff`) VALUES (10, 'Novčanik', 1);


#
# TABLE STRUCTURE FOR: currency
#

DROP TABLE IF EXISTS currency;

CREATE TABLE `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `deff` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

INSERT INTO currency (`id`, `name`, `deff`) VALUES (53, 'kn', 1);
INSERT INTO currency (`id`, `name`, `deff`) VALUES (54, 'eur', 0);


#
# TABLE STRUCTURE FOR: inputCategory
#

DROP TABLE IF EXISTS inputCategory;

CREATE TABLE `inputCategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `income_outcome` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (32, 'Telefon', 0);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (33, 'Plaća', 1);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (34, 'IT', 1);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (35, 'Vođenje', 1);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (36, 'Auto', 0);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (37, 'Špeza', 0);
INSERT INTO inputCategory (`id`, `name`, `income_outcome`) VALUES (38, 'Ostalo', 0);


#
# TABLE STRUCTURE FOR: recording
#

DROP TABLE IF EXISTS recording;

CREATE TABLE `recording` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idCurrency` int(11) NOT NULL,
  `idAccounts` int(11) NOT NULL,
  `idinputGroup` int(11) DEFAULT NULL,
  `income` decimal(12,2) DEFAULT NULL,
  `dateEntry` date NOT NULL,
  `outcome` decimal(12,2) DEFAULT NULL,
  `pending` tinyint(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `transaction` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8;

INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (124, 53, 9, 33, '5000.00', '2012-02-02', NULL, 0, 'plaća', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (125, 53, 10, 33, '1000.00', '2012-02-07', NULL, 0, 'IT', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (126, 53, 10, 32, NULL, '2012-01-30', '100.00', 0, 'Telefon', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (128, 53, 9, 34, '2000.00', '2012-01-16', NULL, 0, 'Hosting', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (130, 53, 10, 38, NULL, '2012-02-10', '250.00', 0, 'Osiguranje', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (132, 53, 10, 34, '250.00', '2012-02-16', NULL, 0, 'Prijevoz', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (133, 53, 9, 38, NULL, '2012-02-13', '200.00', 0, 'Špeza', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (134, 54, 9, 34, '500.00', '2012-02-14', NULL, 0, 'Zarada', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (135, 54, 9, 38, NULL, '2012-02-10', '333.00', 1, 'karamda', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (136, 53, 10, 34, '10000.00', '2012-02-13', NULL, 0, 'Stiglo', NULL);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (137, 53, 10, NULL, NULL, '2012-02-07', '500.00', 0, 'Transfer', 1);
INSERT INTO recording (`id`, `idCurrency`, `idAccounts`, `idinputGroup`, `income`, `dateEntry`, `outcome`, `pending`, `description`, `transaction`) VALUES (138, 53, 9, NULL, '500.00', '2012-02-07', NULL, 0, 'Transfer', 1);


