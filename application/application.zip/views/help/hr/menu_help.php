<div class="col2">
	<?php echo anchor('help/index','O programu');  ?>
	<br />
	<?php echo anchor('help/index#license','Licenca');  ?>
	<br />
	<?php echo anchor('help/index#inst','Instalacija');  ?>

</div>

<div class="col3">
	<?php echo anchor('help/guide','Matični podaci');  ?>
	<br />
	<?php echo anchor('help/recording','Knjiženje');  ?>
	<br />
	<?php echo anchor('help/transaction','Transakcije');  ?>
</div>

<div class="col4">
	<?php echo anchor('help/allRecords','Svi unosi');  ?>
	<br />
	<?php echo anchor('help/categories','Izv. po vrstama');  ?>
	<br />
	<?php echo anchor('help/search','Pretraga');  ?>
	<br />
	<?php echo anchor('help/backup','Arhiva');  ?>
	

</div> 