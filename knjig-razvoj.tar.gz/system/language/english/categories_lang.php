<?php
$lang['header_name'] = 'Name';
