<?php 
$lang['currency'] = 'Valuta';
$lang['currency_entry'] = "Unos valute ";
$lang['currency_name'] = 'Naziv ';
$lang['header_name'] = 'NAZIV' ;

$lang['curreny_edit'] = 'Izmjena podataka o valuti';

$lang['currency_notdeleted'] = 'Valuta se ne moze obrisati jer postoji u knjizenju!';