<?php
$lang['header_name'] = 'Naziv';
